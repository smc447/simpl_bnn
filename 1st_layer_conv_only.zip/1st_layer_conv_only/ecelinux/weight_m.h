#ifndef MODEL_CONV_NEW
#define MODEL_CONV_NEW

bool w_conv1_new[16][1][3][3] = {
    #include"data/weight_0b"
}; //binary weight
#endif