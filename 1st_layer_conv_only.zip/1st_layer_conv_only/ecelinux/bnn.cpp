//==========================================================================
// bnn.cpp
//==========================================================================
// @brief: A convolution kernel for CNN on digit recognition
#include <algorithm>
#include <ap_axi_sdata.h>
#include <ap_fixed.h>
#include <ap_int.h>
#include <hls_math.h>
#include <hls_stream.h>
#include <math.h>
#include <stdint.h>
#include "layer.h"
#include "model.h"
#include "bnn.h"
#include "weight_m.h"
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;

//----------------------------------------------------------
// Top function
//----------------------------------------------------------

//bool weight1[16][1][3][3] = {{{ { 1, 0, 0 }, { 1, 0, 0 }, { 0, 1, 1 } }}, {{ { 0, 0, 0 }, { 1, 1, 1 }, { 1, 0, 0 } }}, {{ { 0, 0, 0 }, { 1, 1, 0 }, { 1, 1, 1 } }}, {{ { 0, 0, 0 }, { 1, 0, 0 }, { 1, 0, 0 } }}, {{ { 1, 0, 1 }, { 1, 1, 1 }, { 0, 1, 1 } }}, {{ { 0, 0, 0 }, { 0, 1, 1 }, { 1, 1, 1 } }}, {{ { 1, 1, 0 }, { 1, 1, 1 }, { 0, 1, 1 } }}, {{ { 0, 1, 1 }, { 1, 1, 1 }, { 0, 0, 1 } }}, {{ { 1, 1, 1 }, { 1, 0, 0 }, { 0, 1, 1 } }}, {{ { 1, 1, 1 }, { 0, 0, 0 }, { 0, 0, 0 } }}, {{ { 0, 0, 0 }, { 0, 0, 0 }, { 1, 0, 1 } }}, {{ { 0, 0, 0 }, { 0, 0, 1 }, { 1, 1, 1 } }}, {{ { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 1 } }}, {{ { 0, 1, 1 }, { 1, 1, 1 }, { 0, 0, 0 } }}, {{ { 0, 1, 0 }, { 1, 1, 1 }, { 0, 1, 1 } }}, {{ { 0, 0, 1 }, { 1, 1, 0 }, { 1, 1, 0 } }}};


void dut(
    hls::stream<bit32_t> &strm_in,
    hls::stream<bit32_t> &strm_out
)
{
  bit input[MAX_FMAP];
  bit32_t input_l;
  bit32_t output;
  bool input2[1][1][16][16];
  ap_int<6> v2[1][16][16][16];
  //read one test image into digit
  for (int i = 0; i < I_WIDTH1 * I_WIDTH1 / BUS_WIDTH; i++) {
     input_l = strm_in.read();
     for (int j = 0; j < BUS_WIDTH; j++) {
       input[i*BUS_WIDTH+j] = input_l(j,j);
       if(j<16){
        input2[1][1][2*i][j] = input_l(j,j);
       }
       else{
        input2[1][1][2*i+1][j-16] =input_l(j,j);
       }
       
     }
  }
  //call bnn
  //output = bnn_xcel(input);
  output = (int)top(input2, w_conv1_new, v2);
  // write out the result
  strm_out.write(output);
}

//----------------------------------------------------------
// BNN Accelerator
//----------------------------------------------------------
// @param[in] : input - the testing instance
// @return : the predicted digit

bit32_t bnn_xcel(bit input[MAX_FMAP]){
  bit mem_conv1[MAX_FMAP];
  bit mem_conv2[MAX_FMAP];

  /* First Conv Layer */
  pad(input, mem_conv1, 1, I_WIDTH1);
  conv(mem_conv1, mem_conv2, threshold1, 1, N_CHANNEL1, I_WIDTH1+PADDING, 0);
  max_pool(mem_conv2, mem_conv1, N_CHANNEL1, I_WIDTH1);

  /* Second Conv Layer */
  pad(mem_conv1, mem_conv2, N_CHANNEL1, I_WIDTH2);
  conv(mem_conv2, mem_conv1, threshold2, N_CHANNEL1, N_CHANNEL2, I_WIDTH2+PADDING, 1);
  max_pool(mem_conv1, mem_conv2, N_CHANNEL2, I_WIDTH2);

  reshape(mem_conv2, mem_conv1);

  /* Dense Layers */
  dense(mem_conv1, mem_conv2, w_fc1, b_fc1, FC1_UNITS, FC2_UNITS, true);
  dense(mem_conv2, mem_conv1, w_fc2, b_fc2, FC2_UNITS, 10, false);
  
  // find predicted digit 
  bit32_t max_id = 0;
  for(int i = 1; i < 10; i++)
    if(mem_conv1[i])
      max_id = i;
  return max_id;
}


ap_int<6> top(
  bool v0[1][1][16][16],
  bool v1[16][1][3][3],
  ap_int<6> v2[1][16][16][16]
) {     //
  bool conv1_pad[1][1][18][18]; //
  l_hh: for (int hh = 0; hh < 18; hh++) {       //
    l_ww: for (int ww = 0; ww < 18; ww++) {     //
      bool v6;
      if ((ww - 1) >= 0 && ((-ww) + 16) >= 0 && (hh - 1) >= 0 && ((-hh) + 16) >= 0) {   //
        bool v7 = v0[0][0][(hh - 1)][(ww - 1)]; //
        v6 = v7;        //
      } else {
        bool v8 = 0;    //
        v6 = v8;        //
      }
      conv1_pad[0][0][hh][ww] = v6;     //
    }
  }
  l_ff: for (int ff = 0; ff < 16; ff++) {       //
    l_yy: for (int yy = 0; yy < 16; yy++) {     //
      l_xx: for (int xx = 0; xx < 16; xx++) {   //
        ap_int<6> sum_rv;       //
        sum_rv = 0;     //
        l_ry: for (int ry = 0; ry < 3; ry++) {  //
          l_rx: for (int rx = 0; rx < 3; rx++) {        //
            ap_int<6> v15;
            if (((xx + rx) - 1) >= 0 && (((-xx) - rx) + 16) >= 0 && ((yy + ry) - 1) >= 0 && (((-yy) - ry) + 16) >= 0) { //
              bool v16 = conv1_pad[0][0][(yy + ry)][(xx + rx)]; //
              int32_t v17 = v16;        //
              int32_t v18 = 1 - v17;    //
              bool v19 = v1[ff][0][ry][rx];     //
              int32_t v20 = v19;        //
              int32_t v21 = v18 ^ v20;  //
              int32_t v22 = v21 << 1;   //
              int32_t v23 = v22 - 1;    //
              ap_int<6> v24 = v23;      //
              v15 = v24;        //
            } else {
              ap_int<6> v25 = 0;        //
              v15 = v25;        //
            }
            ap_int<6> v26 = sum_rv;     //
            ap_int<6> v27 = v15 + v26;  //
            sum_rv = v27;       //
          }
        }
        ap_int<6> v28 = sum_rv; //
        v2[0][ff][yy][xx] = v28;        //
      }
    }
  }
  
  ofstream myfile;
    myfile.open ("output3.py");
  myfile << "import numpy as np \n";
  myfile << "impl_conv_only2 = np.array([";
  for (int i=0; i<16;i++){
    for(int j=0; j<16; j++){
      for(int m=0;m<16;m++){
        myfile << v2[0][i][j][m]<<",";
      }
    }
  }
  
  myfile.close();
  return v2[0][0][0][0];
}